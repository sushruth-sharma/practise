package com.dxc.model;


public enum Role {
    USER, ADMIN, RECRUITER,ADVERTISER
}
