package com.dxc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationAndLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
